import streamlit as st
import csv
import random
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

st.set_option('deprecation.showPyplotGlobalUse', False)
st.title('Работа с готовым csv файлом')
df = pd.read_csv('data/economic_data.csv')
st.dataframe(df)
fig, axs = plt.subplots(figsize=(20, 5), ncols=2)
axs[0].set_title('Оценка годовой выручки')
axs[1].set_title('Оценка количества сотрудников')
sns.histplot(df['Годовая выручка'], kde=True, ax=axs[0], bins=15)
sns.histplot(df['Количество сотрудников'], kde=True, ax=axs[1], bins=15)
st.pyplot(fig)
correlation_matrix = df.corr()
plt.figure(figsize=(10, 8))
sns.heatmap(data=correlation_matrix, annot=True, cmap='coolwarm', linewidths=.5)
plt.title('График корреляции между переменными')
st.pyplot()
st.write(
    f'Корееляция между «Год основания» и «Годовая выручка»: {correlation_matrix["Год основания"]["Годовая выручка"]}')
df['Стартап'] = df.apply(lambda x: 1 if x['Год основания'] >= 2010 and x['Годовая выручка'] <= 100000 and x[
    'Количество сотрудников'] <= 50 else 0, axis=1)
# Создадим дополнительную колонку данных "Стартап", 1 - стартап, 0 - не стартап
label = ['Стартап', 'Не стартап']  # Имена секторов круговой диаграммы
count_nosu = len(df) - df.sum(axis=0)['Стартап']  # Количество фирм не стартапов
values = [df.sum(axis=0)['Стартап'], count_nosu]  # Данные для построения круговой диаграммы
fig1, ax1 = plt.subplots()


def make_autopct(values):
    def my_autopct(pct):
        total = sum(values)
        val = int(round(pct * total / 100.0))
        return '{p:.2f}%  ({v:d})'.format(p=pct, v=val)

    return my_autopct


# Создание описания каждого сектора диаграммы

wedges, texts, autotexts = ax1.pie(values, labels=label, autopct=make_autopct(values),
                                   colors=['b', 'g'])  # Создание круговой диаграммы
ax1.axis('equal')
ax1.legend(loc='upper left', bbox_to_anchor=(1.0, 1.0), title=f'Всего фирм: {len(df)}')
ax1.set_title('Распределение фирм', fontsize=20)
st.pyplot(fig1)
current_year = 2023
st.write(f"Среднее время существования фирм: {current_year - df.mean()['Год основания']}")
st.write(f'Корееляция между «Год основания» и «Годовая выручка»: {correlation_matrix["Год основания"]["Годовая выручка"]}\nКорелляция близка к нулю, то есть связи между годом основания и годовой выручки нет')