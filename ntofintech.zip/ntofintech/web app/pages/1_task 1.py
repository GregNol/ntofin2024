import streamlit as st
import csv
import random
import pandas as pd


seed = st.text_input(label='Введите seed для random', value='42')
random.seed(int(seed))
years = []
earnings = []
workers = []
for _ in range(1000):
    year = random.randint(1990, 2020)
    years.append(year)
    earning = random.randint(100000, 10000000)
    earnings.append(earning)
    work = random.randint(10, 500)
    workers.append(work)
with open('economic_data.csv', 'w', newline='', encoding="utf-8") as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(['Год основания', 'Годовая выручка', 'Количество сотрудников'])
    for i in range(1000):
        writer.writerow([years[i], earnings[i], workers[i]])
df = pd.read_csv('economic_data.csv')
st.write("Сгенерированные данные")
st.dataframe(df)
st.write("Описание DataFrame")
st.dataframe(df.describe())
years_mean, earnings_mean, workers_mean = df.mean()
years_med, earnings_med, workers_med = df.median()
st.write(f'Средний год основания: {years_mean}')
st.write(f'Средний доход: {earnings_mean}')
st.write(f'Среднее количество сотрудников: {workers_mean}')
st.write(f'Медиана годов основания: {years_med}')
st.write(f'Медиана дохода: {earnings_med}')
st.write(f'Медиана количества сотрудников: {workers_med}')


